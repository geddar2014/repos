﻿using Updater.Apis.Dtos;

namespace Updater.Statistics
{
	public static class GameExtensions
	{
		public static bool HasSameOdd(this GameDto game, int score)
		{
			return score % 2 == (game.Total_Home + game.Total_Away) % 2;
		}
	}
}