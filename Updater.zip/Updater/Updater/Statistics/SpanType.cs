﻿namespace Updater.Statistics
{
	public enum SpanType : byte
	{
		LastTenGames    = 1,
		LastTwentyGames = 2,
		LastSeason      = 3,
		OneYear         = 4,
		TwoYears        = 5,
		ThreeYears      = 6,
		FiveYears       = 7,
		SevenYears      = 8,
		AllTime         = 9
	}
}