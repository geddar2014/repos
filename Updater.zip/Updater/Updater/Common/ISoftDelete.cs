﻿namespace Updater.Common
{
	public interface ISoftDelete
	{
		bool IsDeleted { get; set; }
	}
}