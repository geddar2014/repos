﻿namespace Updater.Common
{
	public interface IHasId
	{
		int Id { get; set; }
	}
}