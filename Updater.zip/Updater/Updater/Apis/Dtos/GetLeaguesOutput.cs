﻿using Newtonsoft.Json;

namespace Updater.Apis.Dtos
{
	public class GetLeaguesOutput
	{
		[JsonConstructor]
		public GetLeaguesOutput(int id, string msTitle)
		{
			League = new LeagueDto(id, msTitle);
		}

		public LeagueDto League { get; set; }
	}
}