﻿namespace Updater.Apis.Dtos
{
	public class TeamDto : DtoBase
	{
		public TeamDto()
		{
		}

		public TeamDto(int id, int countryId, string title, int xBetTeamId)
		{
			Id         = id;
			CountryId  = countryId;
			Title      = title;
			XBetTeamId = xBetTeamId;
		}

		public int CountryId { get; set; }

		public string Title { get; set; }

		public int XBetTeamId { get; set; }
	}
}