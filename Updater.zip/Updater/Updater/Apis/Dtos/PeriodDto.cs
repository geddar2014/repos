﻿using Newtonsoft.Json;

namespace Updater.Apis.Dtos
{
	public class PeriodDto
	{
		[JsonProperty("Score1")]
		public int Home { get; set; }

		[JsonProperty("Score2")]
		public int Away { get; set; }
	}
}