﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Updater.Apis.Args
{
	public class DateArgs : IRunnerArgs
	{
		protected DateArgs()
		{
		}

		private DateArgs(DateTime date)
		{
			Date = date;
		}

		[JsonConverter(typeof(UnixDateTimeConverter))]
		public DateTime Date { get; protected set; }

		public IRunnerArgs Create(params object[] parameters)
		{
			return new DateArgs((DateTime) parameters[0]);
		}

		public static DateArgs Create(DateTime date)
		{
			return (DateArgs) new DateArgs().Create((object) date);
		}
	}
}