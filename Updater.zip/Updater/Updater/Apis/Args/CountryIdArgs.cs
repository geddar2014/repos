﻿namespace Updater.Apis.Args
{
	public class CountryIdArgs : IRunnerArgs
	{
		protected CountryIdArgs()
		{
		}

		private CountryIdArgs(int countryId)
		{
			CountryId = countryId;
		}

		public int CountryId { get; protected set; }

		public IRunnerArgs Create(params object[] parameters)
		{
			return new CountryIdArgs((int) parameters[0]);
		}

		public static CountryIdArgs Create(int countryId)
		{
			return (CountryIdArgs) new CountryIdArgs().Create((object) countryId);
		}
	}
}