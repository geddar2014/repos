﻿namespace Updater.Apis.Args
{
	public interface IRunnerArgs
	{
		IRunnerArgs Create(params object[] parameters);
	}
}