﻿using System.Collections.Generic;
using Updater.Apis.Dtos;

namespace Updater.Repositories
{
	public interface IStageRepository
	{
		void AddOrUpdate_Stages(IList<StageDto> stagesInput, out int inserted, out int updated);
		void Insert_Stages(IList<StageDto> stageList);
		void Update_Stages(IList<StageDto> stageList);
	}
}