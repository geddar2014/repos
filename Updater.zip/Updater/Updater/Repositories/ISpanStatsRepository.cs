﻿using System.Collections.Generic;
using Updater.Statistics;

namespace Updater.Repositories
{
	public interface ISpanStatsRepository
	{
		void Insert_SpanStats(IList<SpanStats> teamList);
	}
}