﻿using System.Collections.Generic;
using Updater.Apis.Dtos;

namespace Updater.Repositories
{
	public interface IGameRepository
	{
		void AddOrUpdate_Games(IList<GameDto> gamesInput, out int inserted, out int updated);
		void Insert_Games(IList<GameDto> gameList);
		void Update_Games(IList<GameDto> gameList);
	}
}